#include "Material.h"

using namespace std;

Material::Material() {
    this -> ke = glm::vec3(0.0f, 0.0f, 0.0f);
    this -> kd = glm::vec3(float(rand())/RAND_MAX, float(rand())/RAND_MAX, float(rand())/RAND_MAX);
    this -> ks = glm::vec3(float(rand())/RAND_MAX, float(rand())/RAND_MAX, float(rand())/RAND_MAX);
    this -> s = (float(rand())/RAND_MAX) * 100;
    // this -> ka = glm::vec3(0.2, 0.2, 0.2);
    // this -> kd = glm::vec3(0.2, 0.2, 0.2);
    // this -> ks = glm::vec3(0.2, 0.2, 0.2);
    // this -> s = 300;
}

void Material::setKE(float a, float b, float c)
{
    this -> ke = glm::vec3(a, b, c);
}

void Material::setKD(float a, float b, float c)
{
    this -> kd = glm::vec3(a, b, c);
}

void Material::setKS(float a, float b, float c)
{
    this -> ks = glm::vec3(a, b, c);
}

void Material::setS(float s)
{
    this -> s = s;
}

glm::vec3 Material::getKE()
{
    return this->ke;
}

glm::vec3 Material::getKD()
{
    return this->kd;
}

glm::vec3 Material::getKS()
{
    return this->ks;
}

float Material::getS()
{
    return this->s;
}