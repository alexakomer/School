#ifndef Material_H
#define Material_H

#include <cmath>
#include <iostream>

#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include <glm/glm.hpp>
#include <glm/ext.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include "GLSL.h"
#include "MatrixStack.h"
#include "Shape.h"
#include "Program.h"
#include "Light.h"

#include <string>
#include <vector>
#include <memory>

using namespace std;

class Material
{
public:
	Material();

    // setters
    void setKE(float a, float b, float c);
    void setKD(float a, float b, float c);
    void setKS(float a, float b, float c);
    void setS(float s);

    // getters
    glm::vec3 getKE();
    glm::vec3 getKD();
    glm::vec3 getKS();
    float getS();

private:
    glm::vec3 ke;
    glm::vec3 kd;
    glm::vec3 ks;
    float s;
};

#endif