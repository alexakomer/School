#include <cassert>
#include <cstring>
#define _USE_MATH_DEFINES
#include <cmath>
#include <iostream>

#define GLEW_STATIC
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#define GLM_FORCE_RADIANS
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>

#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

#include "Camera.h"
#include "GLSL.h"
#include "MatrixStack.h"
#include "Material.h"
#include "Program.h"
#include "Shape.h"
#include "Light.h"

#define MAX_LIGHT_NUM 20

using namespace std;

GLFWwindow *window; // Main application window
string RESOURCE_DIR = "./"; // Where the resources are loaded from
bool OFFLINE = false;

shared_ptr<Camera> camera;
shared_ptr<Program> prog; // blinn-phong
shared_ptr<Program> prog2; // surface blinn-phong
shared_ptr<Shape> bunny; // bunny
shared_ptr<Shape> teapot; // teapot
shared_ptr<Shape> plane; // plane
shared_ptr<Shape> wisp; // wisp (sphere for lights)
vector<Material> materialList;
vector<Light> lightList;
vector<float> randList;
int numObjects = 100;
int numLights = 20;

map<string,GLuint> bufIDs;
int indCountSphere;
float yMinSphere = FLT_MAX;
map<string,GLuint> bufIDs2;
int indCountSurface;
float yMinSurface = FLT_MAX;

bool keyToggles[256] = {false}; // only for English keyboards!

// This function is called when a GLFW error occurs
static void error_callback(int error, const char *description)
{
	cerr << description << endl;
}

// This function is called when a key is pressed
static void key_callback(GLFWwindow *window, int key, int scancode, int action, int mods)
{
	if(key == GLFW_KEY_ESCAPE && action == GLFW_PRESS) {
		glfwSetWindowShouldClose(window, GL_TRUE);
	}
}

// This function is called when the mouse is clicked
static void mouse_button_callback(GLFWwindow *window, int button, int action, int mods)
{
	// Get the current mouse position.
	double xmouse, ymouse;
	glfwGetCursorPos(window, &xmouse, &ymouse);
	// Get current window size.
	int width, height;
	glfwGetWindowSize(window, &width, &height);
	if(action == GLFW_PRESS) {
		bool shift = (mods & GLFW_MOD_SHIFT) != 0;
		bool ctrl  = (mods & GLFW_MOD_CONTROL) != 0;
		bool alt   = (mods & GLFW_MOD_ALT) != 0;
		camera->mouseClicked((float)xmouse, (float)ymouse, shift, ctrl, alt);
	}
}

// This function is called when the mouse moves
static void cursor_position_callback(GLFWwindow* window, double xmouse, double ymouse)
{
	int state = glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT);
	if(state == GLFW_PRESS) {
		camera->mouseMoved((float)xmouse, (float)ymouse);
	}
}

static void char_callback(GLFWwindow *window, unsigned int key)
{
}

// If the window is resized, capture the new size and reset the viewport
static void resize_callback(GLFWwindow *window, int width, int height)
{
	glViewport(0, 0, width, height);
}

// https://lencerf.github.io/post/2019-09-21-save-the-opengl-rendering-to-image-file/
static void saveImage(const char *filepath, GLFWwindow *w)
{
	int width, height;
	glfwGetFramebufferSize(w, &width, &height);
	GLsizei nrChannels = 3;
	GLsizei stride = nrChannels * width;
	stride += (stride % 4) ? (4 - stride % 4) : 0;
	GLsizei bufferSize = stride * height;
	std::vector<char> buffer(bufferSize);
	glPixelStorei(GL_PACK_ALIGNMENT, 4);
	glReadBuffer(GL_BACK);
	glReadPixels(0, 0, width, height, GL_RGB, GL_UNSIGNED_BYTE, buffer.data());
	stbi_flip_vertically_on_write(true);
	int rc = stbi_write_png(filepath, width, height, nrChannels, buffer.data(), stride);
	if(rc) {
		cout << "Wrote to " << filepath << endl;
	} else {
		cout << "Couldn't write to " << filepath << endl;
	}
}

// This function is called once to initialize the scene and OpenGL
static void init()
{
	// Initialize time.
	glfwSetTime(0.0);
	
	// Set background color.
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	// Enable z-buffer test.
	glEnable(GL_DEPTH_TEST);

	prog = make_shared<Program>(); // BLINN-PHONG SHADER
	prog2 = make_shared<Program>(); // SURFACE BLINN-PHONG SHADER

	// Initialize list of Materials for setting object colors
	for (int i = 0; i < numObjects; i++)
	{	
		Material mat;
		mat.setKS(1.0f, 1.0f, 1.0f);
		mat.setS(10.0f);
		materialList.push_back(mat);
	}

	// Initialize list of Lights
	for (int i = 0; i < numLights; i++)
	{	
		Light l;
		l.setColor(float(rand())/RAND_MAX, float(rand())/RAND_MAX, float(rand())/RAND_MAX);
		lightList.push_back(l);
	}

	// Initialize list of randoms
	for (int i = 0; i < numObjects; i++)
		randList.push_back(float(rand())/RAND_MAX);

	// Blinn-Phong Shader
	prog->setShaderNames(RESOURCE_DIR + "blinn_vert.glsl", RESOURCE_DIR + "blinn_frag.glsl");
	prog->setVerbose(true);
	prog->init();
	prog->addAttribute("aPos");
	prog->addAttribute("aNor");
	prog->addAttribute("aTex");
	prog->addUniform("MV");
	prog->addUniform("invTrans");
	prog->addUniform("P");
	prog->addUniform("lightPosList");
	prog->addUniform("lightColList");
	prog->addUniform("numLights");

	prog->addUniform("ke");
	prog->addUniform("kd");
	prog->addUniform("ks");
	prog->addUniform("s");
	prog->setVerbose(false);

	// Surface Shader
	prog2->setShaderNames(RESOURCE_DIR + "surface_vert.glsl", RESOURCE_DIR + "blinn_frag.glsl");
	prog2->setVerbose(true);
	prog2->init();
	prog2->addAttribute("aPos");
	prog2->addUniform("t");
	prog2->addUniform("MV");
	prog2->addUniform("invTrans");
	prog2->addUniform("P");
	prog2->addUniform("lightPosList");
	prog2->addUniform("lightColList");
	prog2->addUniform("numLights");

	prog2->addUniform("ke");
	prog2->addUniform("kd");
	prog2->addUniform("ks");
	prog2->addUniform("s");
	prog2->setVerbose(false);

	camera = make_shared<Camera>();
	camera->setInitDistance(7.0f); // Camera's initial Z translation
	
	bunny = make_shared<Shape>();
	bunny->loadMesh(RESOURCE_DIR + "bunny.obj");
	bunny->init();
	
	teapot = make_shared<Shape>();
	teapot->loadMesh(RESOURCE_DIR + "teapot.obj");
	teapot->init();

	plane = make_shared<Shape>();
	plane->loadMesh(RESOURCE_DIR + "square.obj");
	plane->init();
	
	wisp = make_shared<Shape>();
	wisp->loadMesh(RESOURCE_DIR + "sphere2.obj");
	wisp->init();


	//
	// SPHERE VERTEX DATA
	//

	vector<float> posBuf;
	vector<float> norBuf;
	vector<unsigned int> indBuf;

	// Define the number of rows and columns
	const int samples = 50;

	// Define the step size between grid points
	const float stepSize = 1.0f / (samples - 1);

	// Generate the grid points
	for (int col = 0; col < samples; col++) 
	{
		for (int row = 0; row < samples; row++) 
		{
			// Compute the position of the grid point in spherical coordinates
			float theta = ((float)row / (samples - 1)) * M_PI;
			float phi = ((float)col / (samples - 1)) * 2.0f * M_PI;

			float x = sin(theta) * sin(phi);
			float y = cos(theta);
			float z = sin(theta) * cos(phi);

			// Add the position and normal vectors to their respective buffers
			posBuf.push_back(x);
			posBuf.push_back(y);

			if (posBuf.back() < yMinSphere)
				yMinSphere = posBuf.back();

			posBuf.push_back(z);

			// Normal buffer for spherical coordinates
			norBuf.push_back(x);
			norBuf.push_back(y);
			norBuf.push_back(z);

			// Generate indices
			if (row < samples - 1 && col < samples - 1)
			{
				int idx0 = (col * samples) + row;
				int idx1 = (col * samples) + row + 1;
				int idx2 = (col * samples) + samples + row + 1;
				int idx3 = (col * samples) + samples + row;

				// Add indices for the first triangle
				indBuf.push_back(idx0);
				indBuf.push_back(idx1);
				indBuf.push_back(idx2);

				// Add indices for the second triangle
				indBuf.push_back(idx0);
				indBuf.push_back(idx2);
				indBuf.push_back(idx3);
			}
		}
	}
	
	// Total number of indices
	indCountSphere = (int)indBuf.size();

	// Generate buffer IDs and put them in the bufIDs map.
	GLuint tmp[3];
	glGenBuffers(3, tmp);
	bufIDs["bPos"] = tmp[0];
	bufIDs["bNor"] = tmp[1];
	bufIDs["bInd"] = tmp[2];
	glBindBuffer(GL_ARRAY_BUFFER, bufIDs["bPos"]);
	glBufferData(GL_ARRAY_BUFFER, posBuf.size()*sizeof(float), &posBuf[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, bufIDs["bNor"]);
	glBufferData(GL_ARRAY_BUFFER, norBuf.size()*sizeof(float), &norBuf[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufIDs["bInd"]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indBuf.size()*sizeof(unsigned int), &indBuf[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
	
	assert(norBuf.size() == posBuf.size());


	//
	// SURFACE VERTEX DATA
	//

	vector<float> posBuf2;
	vector<float> norBuf2;
	vector<unsigned int> indBuf2;

	// Define the number of rows and columns
	const int samples2 = 50;

	// Define the step size between grid points
	const float stepSize2 = 1.0f / (samples2 - 1);

	// Generate the grid points
	for (int col = 0; col < samples2; col++) 
	{
		for (int row = 0; row < samples2; row++) 
		{
			// Compute the position of the grid point in spherical coordinates
			float x = ((float)row / (samples2 - 1)) * 2.0f * M_PI;
			float theta = ((float)col / (samples2 - 1)) * 2.0f * M_PI;

			// float f = cos(x) + 2.0f;
			// float y = f * cos(theta);
			// float z = f * sin(theta);

			// Calculate the x, y, and z positions and push them back into a buffer
			// posBuf2.push_back(x);
			// posBuf2.push_back(y);

			// if (posBuf2.back() < yMinSurface)
			// 	yMinSurface = posBuf2.back();

			// posBuf2.push_back(z);

			posBuf2.push_back(x);
			posBuf2.push_back(theta);
			posBuf2.push_back(0.0f);

			// Compute the derivatives of the parametrized equation with respect to x and theta
			// float df_dx = -sin(x);
			// float df_dtheta = -f * sin(theta);

			// // Compute the normal vector
			// float nx = df_dx * cos(theta);
			// float ny = df_dx * sin(theta);
			// float nz = df_dtheta;

			// // Normalize the normal vector
			// float n_length = sqrt(nx * nx + ny * ny + nz * nz);
			// nx /= n_length;
			// ny /= n_length;
			// nz /= n_length;

			// // Calculate the x, y, and z normals and push them back into a buffer
			// norBuf2.push_back(nx);
			// norBuf2.push_back(ny);
			// norBuf2.push_back(nz);

			norBuf2.push_back(0.0f);
			norBuf2.push_back(0.0f);
			norBuf2.push_back(0.0f);


			// Generate indices
			if (row < samples2 - 1 && col < samples2 - 1)
			{
				int idx0 = (col * samples2) + row;
				int idx1 = (col * samples2) + row + 1;
				int idx2 = (col * samples2) + samples2 + row + 1;
				int idx3 = (col * samples2) + samples2 + row;

				// Add indices for the first triangle
				indBuf2.push_back(idx0);
				indBuf2.push_back(idx1);
				indBuf2.push_back(idx2);

				// Add indices for the second triangle
				indBuf2.push_back(idx0);
				indBuf2.push_back(idx2);
				indBuf2.push_back(idx3);
			}
		}
	}

	
	// Total number of indices
	indCountSurface = (int)indBuf2.size();

	// Generate buffer IDs and put them in the bufIDs map.
	GLuint tmp2[3];
	glGenBuffers(3, tmp2);
	bufIDs2["bPos"] = tmp2[0];
	bufIDs2["bNor"] = tmp2[1];
	bufIDs2["bInd"] = tmp2[2];
	glBindBuffer(GL_ARRAY_BUFFER, bufIDs2["bPos"]);
	glBufferData(GL_ARRAY_BUFFER, posBuf2.size()*sizeof(float), &posBuf2[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, bufIDs2["bNor"]);
	glBufferData(GL_ARRAY_BUFFER, norBuf2.size()*sizeof(float), &norBuf2[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufIDs2["bInd"]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indBuf2.size()*sizeof(unsigned int), &indBuf2[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
	
	assert(norBuf2.size() == posBuf2.size());

	GLSL::checkError(GET_FILE_LINE);
}

// This function is called every frame to draw the scene.
static void render()
{
	// Clear framebuffer.
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	if(keyToggles[(unsigned)'c']) {
		glEnable(GL_CULL_FACE);
	} else {
		glDisable(GL_CULL_FACE);
	}
	if(keyToggles[(unsigned)'z']) {
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	} else {
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	}
	
	// Get current frame buffer size.
	int width, height;
	glfwGetFramebufferSize(window, &width, &height);
	camera->setAspect((float)width/(float)height);

	glViewport(0, 0, width, height);
	
	double t = glfwGetTime();
	
	// Matrix stacks
	auto P = make_shared<MatrixStack>();
	auto MV = make_shared<MatrixStack>();
	
	prog->bind();

	// Apply camera transforms
	P->pushMatrix();
	camera->applyProjectionMatrix(P);

	MV->pushMatrix();
	camera->applyViewMatrix(MV);

	MV->scale(0.33f, 0.33f, 0.33f); // get the grid down to roughly

	vector<glm::vec3> lightPosList;
	vector<glm::vec3> lightPosList2;
	vector<glm::vec3> lightColList;
	int counter = 0;

	// Populate Light list
	for (auto light: lightList)
	{
		float theta = 0.5f * ((float)counter / (numLights - 1)) * t;
		light.setPosition(16.0f * randList[counter] * sin(theta) + 2.0f, 0.5f + sin(theta), 16.0f * randList[counter] * cos(theta) + 2.0f);

		// Fix position of Light in world coords
		lightPosList.push_back(glm::vec3(MV->topMatrix() * glm::vec4(light.getPosition(), 1.0f)));
		lightPosList2.push_back(light.getPosition());
		lightColList.push_back(light.getColor());

		counter++;
	}

	// Draw Lights
   	for (int i = 0; i < numLights; i++)
    {
		MV->pushMatrix();

		glm::vec3 lightPos = lightPosList2[i];
		glm::vec3 lightCol = lightColList[i];

		MV->rotate(2.0f * M_PI / numLights * i, 0.0f, 1.0f, 0.0f);
		MV->translate(lightPos.x, lightPos.y, lightPos.z);
		MV->scale(0.2f, 0.2f, 0.2f);

		glUniformMatrix4fv(prog->getUniform("P"), 1, GL_FALSE, glm::value_ptr(P->topMatrix()));
		glUniformMatrix4fv(prog->getUniform("MV"), 1, GL_FALSE, glm::value_ptr(MV->topMatrix()));
		glUniformMatrix4fv(prog->getUniform("invTrans"), 1, GL_FALSE, glm::value_ptr(glm::transpose(glm::inverse(glm::mat4(MV->topMatrix())))));
		glUniform3f(prog->getUniform("ke"), lightCol.r, lightCol.g, lightCol.b);
		glUniform3f(prog->getUniform("kd"), 0.0f, 0.0f, 0.0f);
		glUniform3f(prog->getUniform("ks"), 0.0f, 0.0f, 0.0f);
		glUniform1f(prog->getUniform("s"), 0.0f);

		wisp->draw(prog);

		MV->popMatrix();
	}

	// Draw plane
	MV->pushMatrix();

	MV->translate(0.0f, -0.5f, 0.0f);
	MV->scale(200.0f, 1.0f, 200.0f);
	MV->rotate(-M_PI/2, 1.0f, 0.0f, 0.0f);

	glUniformMatrix4fv(prog->getUniform("P"), 1, GL_FALSE, glm::value_ptr(P->topMatrix()));
	glUniformMatrix4fv(prog->getUniform("MV"), 1, GL_FALSE, glm::value_ptr(MV->topMatrix()));
	glUniformMatrix4fv(prog->getUniform("invTrans"), 1, GL_FALSE, glm::value_ptr(glm::transpose(glm::inverse(glm::mat4(MV->topMatrix())))));
	glUniform3f(prog->getUniform("ke"), 0.0f, 0.0f, 0.0f);
	glUniform3f(prog->getUniform("kd"), 0.2f, 0.2f, 0.2f);
	glUniform3f(prog->getUniform("ks"), 0.5f, 0.5f, 0.5f);
	glUniform1f(prog->getUniform("s"), 10.0f);
	glUniform1i(prog->getUniform("numLights"), numLights);
	glUniform3fv(prog->getUniform("lightPosList"), lightList.size(), glm::value_ptr(lightPosList[0]));
	glUniform3fv(prog->getUniform("lightColList"), lightList.size(), glm::value_ptr(lightColList[0]));

	plane->draw(prog);

	MV->popMatrix();
	prog->unbind();

	// Use this push to center grid of objects
	MV->pushMatrix();
	MV->translate(-15.0f, 0.0f, -15.0f);

	// Draw bunnies, teapots, and sphere
	for (int i = 0; i < numObjects; i++)
	{
		if (i != 0 && !(i % 10))
			MV->translate(-30.0f, 0.0f, 3.0f);

		MV->pushMatrix();

		Material mat = materialList[i];
		float temp;

		if (i % 4 == 0) // bunny
		{
			prog->bind();
			temp = bunny->yMin;
			MV->translate(0.0f, -0.5f - temp, 0.0f);

			// Just to help randomization
			MV->translate(0, -(0.5 * randList[i]) * temp, 0);
			MV->scale(1 + (0.5 * randList[i]), 1 + (0.5 * randList[i]), 1 + (0.5 * randList[i]));
			
			// Task 2
			MV->rotate(0.4 * t, 0.0f, 1.0f, 0.0f);

			// Just to help randomization
			MV->rotate(randList[i] * M_PI, 0.0f, 1.0f, 0.0f);

			glUniformMatrix4fv(prog->getUniform("P"), 1, GL_FALSE, glm::value_ptr(P->topMatrix()));
			glUniformMatrix4fv(prog->getUniform("MV"), 1, GL_FALSE, glm::value_ptr(MV->topMatrix()));
			glUniformMatrix4fv(prog->getUniform("invTrans"), 1, GL_FALSE, glm::value_ptr(glm::transpose(glm::inverse(glm::mat4(MV->topMatrix())))));
			glUniform3f(prog->getUniform("ke"), mat.getKE()[0], mat.getKE()[1], mat.getKE()[2]);
			glUniform3f(prog->getUniform("kd"), mat.getKD()[0], mat.getKD()[1], mat.getKD()[2]);
			glUniform3f(prog->getUniform("ks"), mat.getKS()[0], mat.getKS()[1], mat.getKS()[2]);
			glUniform1f(prog->getUniform("s"), mat.getS());
			glUniform1i(prog->getUniform("numLights"), numLights);
			glUniform3fv(prog->getUniform("lightPosList"), lightList.size(), glm::value_ptr(lightPosList[0]));
			glUniform3fv(prog->getUniform("lightColList"), lightList.size(), glm::value_ptr(lightColList[0]));

			bunny->draw(prog);
			prog->unbind();
		}
		else if (i % 4 == 1) // teapot
		{
			prog->bind();
			temp = teapot->yMin;
			MV->translate(0.0f, -0.5f - temp, 0.0f);

			// Just to help randomization
			MV->translate(0, -(0.5 * randList[i]) * temp, 0);
			MV->scale(1 + (0.5 * randList[i]), 1 + (0.5 * randList[i]), 1 + (0.5 * randList[i]));
		
			// Just to help randomization
			MV->rotate(randList[i] * M_PI, 0.0f, 1.0f, 0.0f);

			// Task 3
			glm::mat4 S(1.0f);
			S[1][2] = 0.5f * cos(t);
			MV->multMatrix(S);

			glUniformMatrix4fv(prog->getUniform("P"), 1, GL_FALSE, glm::value_ptr(P->topMatrix()));
			glUniformMatrix4fv(prog->getUniform("MV"), 1, GL_FALSE, glm::value_ptr(MV->topMatrix()));
			glUniformMatrix4fv(prog->getUniform("invTrans"), 1, GL_FALSE, glm::value_ptr(glm::transpose(glm::inverse(glm::mat4(MV->topMatrix())))));
			glUniform3f(prog->getUniform("ke"), mat.getKE()[0], mat.getKE()[1], mat.getKE()[2]);
			glUniform3f(prog->getUniform("kd"), mat.getKD()[0], mat.getKD()[1], mat.getKD()[2]);
			glUniform3f(prog->getUniform("ks"), mat.getKS()[0], mat.getKS()[1], mat.getKS()[2]);
			glUniform1f(prog->getUniform("s"), mat.getS());
			glUniform1i(prog->getUniform("numLights"), numLights);
			glUniform3fv(prog->getUniform("lightPosList"), lightList.size(), glm::value_ptr(lightPosList[0]));
			glUniform3fv(prog->getUniform("lightColList"), lightList.size(), glm::value_ptr(lightColList[0]));

			teapot->draw(prog);
			prog->unbind();
		}
		else if (i % 4 == 2) // sphere
		{
			prog->bind();
			temp = yMinSphere;
			MV->translate(0.0f, -0.5f - temp, 0.0f);

			// Just to help randomization
			MV->translate(0, -(0.5 * randList[i]) * temp, 0);
			MV->scale(1 + (0.5 * randList[i]), 1 + (0.5 * randList[i]), 1 + (0.5 * randList[i]));
		
			// Task 4
			float y = 1.3 * (0.5 * sin((2.0f * M_PI / 1.7) * (t + 0.9)) + 0.5);
			float s = -0.5 * (0.5 * cos((4.0f * M_PI / 1.7) * (t + 0.9)) + 0.5) + 1;
			MV->translate(0, y, 0);
			MV->scale(s, 1, s);

			// Just to help randomization
			MV->rotate(randList[i] * M_PI, 0.0f, 1.0f, 0.0f);

			glUniformMatrix4fv(prog->getUniform("P"), 1, GL_FALSE, value_ptr(P->topMatrix()));
			glEnableVertexAttribArray(prog->getAttribute("aPos"));
			GLSL::checkError(GET_FILE_LINE);
			glEnableVertexAttribArray(prog->getAttribute("aNor"));
			GLSL::checkError(GET_FILE_LINE);
			glBindBuffer(GL_ARRAY_BUFFER, bufIDs["bPos"]);
			glVertexAttribPointer(prog->getAttribute("aPos"), 3, GL_FLOAT, GL_FALSE, 0, (void *)0);
			glBindBuffer(GL_ARRAY_BUFFER, bufIDs["bNor"]);
			glVertexAttribPointer(prog->getAttribute("aNor"), 3, GL_FLOAT, GL_FALSE, 0, (void *)0);
			glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufIDs["bInd"]);
			glUniformMatrix4fv(prog->getUniform("MV"), 1, GL_FALSE, value_ptr(MV->topMatrix()));
			glUniformMatrix4fv(prog->getUniform("invTrans"), 1, GL_FALSE, glm::value_ptr(glm::transpose(glm::inverse(glm::mat4(MV->topMatrix())))));
	
			glUniform3f(prog->getUniform("ke"), mat.getKE()[0], mat.getKE()[1], mat.getKE()[2]);
			glUniform3f(prog->getUniform("kd"), mat.getKD()[0], mat.getKD()[1], mat.getKD()[2]);
			glUniform3f(prog->getUniform("ks"), mat.getKS()[0], mat.getKS()[1], mat.getKS()[2]);
			glUniform1f(prog->getUniform("s"), mat.getS());
			glUniform1i(prog->getUniform("numLights"), numLights);
			glUniform3fv(prog->getUniform("lightPosList"), lightList.size(), glm::value_ptr(lightPosList[0]));
			glUniform3fv(prog->getUniform("lightColList"), lightList.size(), glm::value_ptr(lightColList[0]));

			glDrawElements(GL_TRIANGLES, indCountSphere, GL_UNSIGNED_INT, (void *)0);
			glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
			glBindBuffer(GL_ARRAY_BUFFER, 0);
			glDisableVertexAttribArray(prog->getAttribute("aNor"));
			glDisableVertexAttribArray(prog->getAttribute("aPos"));

			prog->unbind();
		}
		else // surface
		{
			prog2->bind();
			// temp = yMinSurface;
			temp = 0.0f;
			MV->translate(0.0f, -0.5f - temp, 0.0f);

			// Just to help randomization
			MV->translate(0, -(0.5 * randList[i]) * temp, 0);
			MV->scale(1 + (0.5 * randList[i]), 1 + (0.5 * randList[i]), 1 + (0.5 * randList[i]));
			MV->rotate(randList[i] * M_PI, 0.0f, 1.0f, 0.0f);

			MV->scale(0.25f, 0.25f, 0.25f); // TEMP FIX - NEED TO CREATE POINTS CORRECTLY
			MV->rotate(M_PI/2, 1.0f, 0.0f, 0.0f);
			MV->rotate(M_PI/2, 0.0f, 1.0f, 0.0f);


			glUniform1f(prog2->getUniform("t"), t);
			glUniformMatrix4fv(prog2->getUniform("P"), 1, GL_FALSE, value_ptr(P->topMatrix()));
			glEnableVertexAttribArray(prog2->getAttribute("aPos"));
			GLSL::checkError(GET_FILE_LINE);
			// glEnableVertexAttribArray(prog->getAttribute("aNor"));
			GLSL::checkError(GET_FILE_LINE);
			glBindBuffer(GL_ARRAY_BUFFER, bufIDs2["bPos"]);
			glVertexAttribPointer(prog2->getAttribute("aPos"), 3, GL_FLOAT, GL_FALSE, 0, (void *)0);
			glBindBuffer(GL_ARRAY_BUFFER, bufIDs2["bNor"]);
			// glVertexAttribPointer(prog->getAttribute("aNor"), 3, GL_FLOAT, GL_FALSE, 0, (void *)0);
			glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufIDs2["bInd"]);
			glUniformMatrix4fv(prog2->getUniform("MV"), 1, GL_FALSE, value_ptr(MV->topMatrix()));
			glUniformMatrix4fv(prog2->getUniform("invTrans"), 1, GL_FALSE, glm::value_ptr(glm::transpose(glm::inverse(glm::mat4(MV->topMatrix())))));
	
			glUniform3f(prog2->getUniform("ke"), mat.getKE()[0], mat.getKE()[1], mat.getKE()[2]);
			glUniform3f(prog2->getUniform("kd"), mat.getKD()[0], mat.getKD()[1], mat.getKD()[2]);
			glUniform3f(prog2->getUniform("ks"), mat.getKS()[0], mat.getKS()[1], mat.getKS()[2]);
			glUniform1f(prog2->getUniform("s"), mat.getS());
			glUniform1i(prog2->getUniform("numLights"), numLights);
			glUniform3fv(prog2->getUniform("lightPosList"), lightList.size(), glm::value_ptr(lightPosList[0]));
			glUniform3fv(prog2->getUniform("lightColList"), lightList.size(), glm::value_ptr(lightColList[0]));

			glDrawElements(GL_TRIANGLES, indCountSurface, GL_UNSIGNED_INT, (void *)0);
			glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
			glBindBuffer(GL_ARRAY_BUFFER, 0);
			// glDisableVertexAttribArray(prog->getAttribute("aNor"));
			glDisableVertexAttribArray(prog2->getAttribute("aPos"));

			prog2->unbind();
		}

		MV->popMatrix();
		MV->translate(3.0f, 0.0f, 0.0f);
	}

	MV->popMatrix();

	MV->popMatrix();
	P->popMatrix();
	
	GLSL::checkError(GET_FILE_LINE);
	
	if(OFFLINE) {
		saveImage("output.png", window);
		GLSL::checkError(GET_FILE_LINE);
		glfwSetWindowShouldClose(window, true);
	}
}

int main(int argc, char **argv)
{
	if(argc < 2) {
		cout << "Usage: A4 RESOURCE_DIR" << endl;
		return 0;
	}
	RESOURCE_DIR = argv[1] + string("/");
	
	// Optional argument
	if(argc >= 3) {
		OFFLINE = atoi(argv[2]) != 0;
	}

	// Set error callback.
	glfwSetErrorCallback(error_callback);
	// Initialize the library.
	if(!glfwInit()) {
		return -1;
	}
	// Create a windowed mode window and its OpenGL context.
	window = glfwCreateWindow(640, 480, "Alex Akomer", NULL, NULL);
	if(!window) {
		glfwTerminate();
		return -1;
	}
	// Make the window's context current.
	glfwMakeContextCurrent(window);
	// Initialize GLEW.
	glewExperimental = true;
	if(glewInit() != GLEW_OK) {
		cerr << "Failed to initialize GLEW" << endl;
		return -1;
	}
	glGetError(); // A bug in glewInit() causes an error that we can safely ignore.
	cout << "OpenGL version: " << glGetString(GL_VERSION) << endl;
	cout << "GLSL version: " << glGetString(GL_SHADING_LANGUAGE_VERSION) << endl;
	GLSL::checkVersion();
	// Set vsync.
	glfwSwapInterval(1);
	// Set keyboard callback.
	glfwSetKeyCallback(window, key_callback);
	// Set char callback.
	glfwSetCharCallback(window, char_callback);
	// Set cursor position callback.
	glfwSetCursorPosCallback(window, cursor_position_callback);
	// Set mouse button callback.
	glfwSetMouseButtonCallback(window, mouse_button_callback);
	// Set the window resize call back.
	glfwSetFramebufferSizeCallback(window, resize_callback);
	// Initialize scene.
	init();
	// Loop until the user closes the window.
	while(!glfwWindowShouldClose(window)) {
		// Render scene.
		render();
		// Swap front and back buffers.
		glfwSwapBuffers(window);
		// Poll for and process events.
		glfwPollEvents();
	}
	// Quit program.
	glfwDestroyWindow(window);
	glfwTerminate();
	return 0;
}
