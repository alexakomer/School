#ifndef Light_H
#define Light_H

#include <cmath>
#include <iostream>

#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include "GLSL.h"
#include "MatrixStack.h"
#include "Shape.h"
#include "Program.h"
#include "Material.h"

#include <string>
#include <vector>
#include <memory>

using namespace std;

class Light
{
public:
	Light();

    // getters
    glm::vec3 getPosition();
    glm::vec3 getColor();

    // setters
    void setPosition(float x, float y, float z);
    void setColor(float a, float b, float c);

private:
    glm::vec3 position;
    glm::vec3 color;
};

#endif