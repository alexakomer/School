#include "Material.h"

using namespace std;

Material::Material() {
    // this -> ka = glm::vec3(rand(), rand(), rand());
    // this -> kd = glm::vec3(rand(), rand(), rand());
    // this -> ks = glm::vec3(rand(), rand(), rand());
    // this -> s = rand() % 300;
    this -> ka = glm::vec3(0.2, 0.2, 0.2);
    this -> kd = glm::vec3(0.2, 0.2, 0.2);
    this -> ks = glm::vec3(0.2, 0.2, 0.2);
    this -> s = 300;
}

void Material::setKA(float a, float b, float c)
{
    this -> ka = glm::vec3(a, b, c);
}

void Material::setKD(float a, float b, float c)
{
    this -> kd = glm::vec3(a, b, c);
}

void Material::setKS(float a, float b, float c)
{
    this -> ks = glm::vec3(a, b, c);
}

void Material::setS(float s)
{
    this -> s = s;
}

glm::vec3 Material::getKA()
{
    return this->ka;
}

glm::vec3 Material::getKD()
{
    return this->kd;
}

glm::vec3 Material::getKS()
{
    return this->ks;
}

float Material::getS()
{
    return this->s;
}