#include "Light.h"

using namespace std;

Light::Light() {
    this->position = glm::vec3(0.0f, 0.0f, 0.0f);
    this->color = glm::vec3(1.0f, 1.0f, 1.0f);
}

void Light::setPosition(float x, float y, float z)
{
    this -> position = glm::vec3(x, y, z);
}

void Light::setColor(float a, float b, float c)
{
    this -> color = glm::vec3(a, b, c);
}

glm::vec3 Light::getPosition()
{
    return this -> position;
}

glm::vec3 Light::getColor()
{
    return this -> color;
}
