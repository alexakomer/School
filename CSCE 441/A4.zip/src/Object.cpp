#include "Object.h"

using namespace std;

Object::Object(shared_ptr<Material> mat, shared_ptr<Shape> shp) {
    this -> mat = mat;
    this -> shp = shp;
}

shared_ptr<Material> Object::getMaterial()
{
    return this->mat;
}

shared_ptr<Shape> Object::getShape()
{
    return this->shp;
}